﻿function selec(numero, codtcr, codalta, nomtcr, num, total, numtcr) {
  var subCadena = numtcr.substring(5, 9);
  document.getElementById("NumContrt").value = numero;
  document.getElementById("CnAlt").value = codalta;
  document.getElementById("CodTCR").value = codtcr;
  document.getElementById("GlsTcr").value = nomtcr;
  document.getElementById("NumTCR").value = subCadena;
  document.getElementById("TipoMov").value = document.getElementById(numero).value;

  if (total > 1) {
  for (var i = 0; i < total; i++) {
      if (i == num) {
        document.getElementById("numtcr" + i).checked = true;
      } else {
        document.getElementById("numtcr" + i).checked = false;
      }

    }  
  }
   
  if (total == 1) {
  document.getElementById("numtcr0").checked = true;  
  }

}

function numerotcrn(num, codtcr, codalta, nomtcr, id, total, numtcr) {
  var subCadena = numtcr.substring(5, 9);
  document.getElementById("NumContrt").value = num;
  document.getElementById("CnAlt").value = codalta;
  document.getElementById("CodTCR").value = codtcr;
  document.getElementById("GlsTcr").value = nomtcr;
  document.getElementById("NumTCR").value = subCadena;

  document.getElementById("TipoMov").value = document.getElementById(num).value;

  if (total > 1)
    for (var i = 0; i < total; i++) {
      if (i == id) {
        document.getElementById("numtcr" + i).checked = true;
      } else {
        document.getElementById("numtcr" + i).checked = false;
      }

    }

}

 function pasar() {

     $('#ntf-loading').show();
   if (document.getElementById("TipoFac").value == 'F') {
     
    var fechaSeleccionada = document.getElementById("fechaFacturacion");
    if (document.getElementById("fechaFacturacion").value !== "") {
      var fechaSelect = fechaSeleccionada.options[fechaSeleccionada.selectedIndex].text;
      var dateParts = fechaSelect.split("/");
      var date = dateParts[2] + "-" + dateParts[1] + "-" + dateParts[0];
      document.getElementById("PeriFac").value = date;
    } 
     else {
          var todayDate = {day: new Date().getDate(), month: new Date().getMonth(), year: new Date().getFullYear()};
          var dia, mes;
      
          if (todayDate.month < 9) {
            mes = "0" + (todayDate.month+1);
          }
      else {
            mes = (todayDate.month+1);
          }
          if (todayDate.day < 10) {
            dia = "0" + todayDate.day;
          }
      else {
            dia = todayDate.day;
          }
          document.getElementById("PeriFac").value = todayDate.year + "-" + mes + "-" + dia;
       }
   }
  document.getElementById("form1").action="/transa/productos/sac2/selmovimientos_view.asp";
  document.getElementById("form1").submit();
     
}

function popup(Nrotrx, Pagina) {
  
  var txtTransaccion = "";
  var txtFecha = "";
  var txtMonto = "";
  var txtTipoB = "";
  var txtCiudad = "";
  var txtRubro = "";
  var txtComercio = "";
  var txtMotivo = "";
  var NumTCR = "";
  var total = $("#txtNumero").val();

  txtTransaccion = $("#txtTransaccion" + Nrotrx).val();
  txtFecha = $("#txtFecha" + Nrotrx).val(); 
  txtMonto = $("#txtMonto" + Nrotrx).val(); 
  txtTipoB = $("#txtTipB" + Nrotrx).val();  
  txtCiudad = $("#txtCiudad" + Nrotrx).val(); 
  txtRubro = $("#txtRubro" + Nrotrx).val(); 
  txtComercio = $("#txtComercio" + Nrotrx).val(); 
  NumTCR = $("#txtTCR" + Nrotrx).val(); 

  // definimos la anchura y altura de la ventana
  var altura = 450;
  var anchura = 550;

  // calculamos la posicion x e y para centrar la ventana
  var y = parseInt((window.screen.height/2)-(altura/2));
  var x = parseInt((window.screen.width/2)-(anchura/2));

  document.getElementById("txtTransaccion").value = txtTransaccion;
  document.getElementById("Fecha").value = txtFecha;
  document.getElementById("txtMonto").value = txtMonto;
  document.getElementById("txtTipoB").value = txtTipoB;
  document.getElementById("txtCiudad").value = txtCiudad;
  document.getElementById("txtRubro").value = txtRubro;
  document.getElementById("txtComercio").value = txtComercio;
  document.getElementById("NumTCR").value = NumTCR;
  
  document.getElementById("Nrotrx").value = Nrotrx;
  //window.open(Pagina, "V2", "resizable=no,menubar=no,left=350,top=160,location=no,toolbar=no,status=no,scrollbars=yes,directories=no,width=550,height=450");
  window.open(Pagina, "V2", "resizable=no,menubar=no,left="+x+",top="+y+",location=no,toolbar=no,status=no,scrollbars=no,directories=no,width="+anchura+",height="+altura+"");
  
  document.getElementById("form1").target = "V2";
  document.getElementById("form1").action = Pagina;
  document.getElementById("form1").submit();
  document.getElementById("form1").target = "";
}

function cambiar_tipomov(tipomov) {
  document.getElementById("TipoMov").value = tipomov;
 
  if (tipomov == "N") {
    document.getElementById("form1").action = "movFacturados_view_m.asp";
  
  } else {
    document.getElementById("form1").action = "movFacturados_view_m.asp";
  }
  
  document.getElementById("form1").submit();
}

function notificar() {
  $('#ntf-loading').show();
  
  document.getElementById("form1").action = "selMovimientos_view.asp"
  document.getElementById("form1").submit();
}

function detalleMov() {
  $('#ntf-loading').show();
  if (document.getElementById("CodSubMov").value == "P"){
      document.getElementById("form1").action = "infReclamo_view.asp"
  } else {
    document.getElementById("indicadores").value = document.getElementById("indicadores").value.slice(0, -1);
    document.getElementById("form1").action = "datosContacto_view.asp"
  }
  document.getElementById("form1").submit();
}

function validateEmail(email) {
  var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return emailRegex.test(email);
}

function validarDireccionEmail() {
  var $inputMail = $("#Mail");
  var email = $("#Mail").val();
  
  if (validateEmail(email)) {
  $inputMail.css("border-bottom-color", "#1BB3BC");
  $("#errorCorreo").text("");
  return true;
  } else {
  $inputMail.css("border-bottom-color", "#EC0000");
  $inputMail.focus();
  $("#errorCorreo").css({"color": "#EC0000", "font-size": "12px", "margin-top": "5px"});
  $("#errorCorreo").text("Ingrese una dirección de correo válida");
  return false;
  }
}


function validatePhone(phone) {
 if (phone.length < 9 || phone.length > 11) {
   return false;
 } else {
   return true;
 }
}

function validarNumeroTelefono() {
  var $inputPhone = $("#Phone");
  var phone = $("#Phone").val();
  
  if (validatePhone(phone)) {
  $inputPhone.css("border-bottom-color", "#1BB3BC");
  $("#errorPhone").text("");
  return true;
  } else {
  $inputPhone.css("border-bottom-color", "#EC0000");
  $inputPhone.focus();
  $("#errorPhone").css({"color": "#EC0000", "font-size": "12px", "margin-top": "5px"});
  $("#errorPhone").text("Ingrese un número válido");
  return false;
  }
}

function validaCampos() {
  var $button = $("#botonContinuar");
  var email = validarDireccionEmail();
  var numero = validarNumeroTelefono();
  if (email && numero) {
    $button.css({
      "pointer-events": "auto",
      "cursor": "pointer",
      "background": "#EC0000"
    });
    return true;
  } else {
    $button.css({
      "pointer-events": "none",
      "cursor": "default",
      "background": "#C2C2C2"
    });
    return false;
  }
  //var email = validarDireccionEmail();
    //var numero = validarNumeroTelefono();
  //return email && numero;
}

function datosContacto() {
  document.getElementById("ref2").value = "true";
  if (document.getElementById("Phone").value != "") {
    if (document.getElementById("Mail").value != "") {
      if (document.getElementById("descrip").value != "") {
        $('#ntf-loading').show();
        document.getElementById("form1").submit();
      } else {
        $("#Mensaje1").html("<h2>Estimado Cliente: Debe Ingresar Detalle del Reclamo</h2>");
        mostrar_modal("DatosContacto");
      }
    } else {
      $("#Mensaje1").html("<h2>Estimado Cliente: Debe Ingresar Email</h2>");
      mostrar_modal("DatosContacto");
    }
  } else {
    $("#Mensaje1").html("<h2>Estimado Cliente: Debe Ingresar Tel&eacute;fono</h2>");
    mostrar_modal("DatosContacto");
  }
}

function validar_sel_chk(num_chk, cAcum) {
  var i, chk_selec, total;
  chk_selec = 0;
  total = num_chk - cAcum;
  for (i = 0; i <= total-1; i++) {
    if (document.getElementById("check" + i).checked) {
      chk_selec = chk_selec + 1;
    }
  }
  // alert(chk_selec);
  if (chk_selec == 0) {
    //alert("Debe seleccionar uno o más movimientos");
    mostrar_modal("_mov");
    return false;
  } else {
    $('#ntf-loading').show();
    document.getElementById("NumMovi").value = Number(num_chk);
  document.getElementById("form1").action = "detalleMovNoFac_view.asp";

    // if (document.getElementById("TipoFac").value == "N") {
      // document.getElementById("form1").action = "detalleMovNoFac_view.asp";
    // } else {
      // document.getElementById("form1").action = "detalleMovFac_view.asp";
    // }
    document.getElementById("form1").submit();
  }
}


function cambiar_value(id_chk, fecha, descripcion, establecimiento, monto, ID_Requerimiento_SAC, Fact_NoFact, Numero_Extracto, Numero_Extracto_Movto, Tipo_Factura_Movimiento, Tipo_Transaccion, Moneda_Movimiento, Fecha_Movimiento, Monto_Total, Monto_Impuesto, Monto_Comision, Monto_Compra, Descripcion_Comercio, Capital_Amortizado, Capital_Pendiente, Interes_Amortizado, Interes_Pendiente, Estado_Movimiento, Comision_Cancelacion, Codigo_Subtipo_Mov, Codigo_Tipo_Cuota, Num_Operacion_Cuota, Numero_Financiacion, Fecha_Ultima_Liquidacion, Monto_Impuesto_Cancela, Monto_Intereses_Regularizacion, Monto_Cancelacion, Contro_Concurrencia, Monto_Interes_Carecencia, Numero_Tarjeta_PAN, Referencia, Cod_Autorizacion, Cod_Actividad, IndSeleccionable,
Cod_Bloqueo, Fecha_Bloqueo, Monto_Cuota, Dsc_Tipo_Factura, Cod_Comercio, Cod_Pais) {



  // var fecha_m = Fecha_Movimiento.split("-");
  // var Fecha_Movimiento2 = fecha_m[2] + "-" + fecha_m[1] + "-" + fecha_m[0];

  // var fecha_b = Fecha_Bloqueo.split("-");
  // var Fecha_Bloqueo2 = fecha_b[2] + "-" + fecha_b[1] + "-" + fecha_b[0];
 
 //alert("Fecha_Movimiento2: "+ Fecha_Movimiento2);
 //alert("Fecha_Bloqueo2: "+ Fecha_Bloqueo2);

 if (document.getElementById("check" + id_chk).checked) {
    document.getElementById("check" + id_chk).value = "1-" + id_chk + "-" + fecha + "-" + Dsc_Tipo_Factura + "-" + establecimiento + "-" + monto;
    // if (id_chk == "0") {
    //  document.getElementById("check_json"+id_chk).value='{"ID_Requerimiento_SAC": "'+ID_Requerimiento_SAC+'", "Fact_NoFact": "'+Fact_NoFact+'", "Numero_Extracto": "'+Numero_Extracto+'", "Numero_Extracto_Movto": "'+Numero_Extracto_Movto+'", "Tipo_Factura_Movimiento": "'+Tipo_Factura_Movimiento+'", "Tipo_Transaccion": "'+Tipo_Transaccion+'", "Moneda_Movimiento": "'+Moneda_Movimiento+'", "Fecha_Movimiento": "'+Fecha_Movimiento+'", "Numero_Tarjeta_PAN": "'+Numero_Tarjeta_PAN+'"}';
    // }
    // if(id_chk > "0" ) {
    //document.getElementById("check_json" + id_chk).value = '{"ID_Requerimiento_SAC": "' + ID_Requerimiento_SAC + '", "Fact_NoFact": "' + Fact_NoFact + '", "Numero_Extracto": "' + Numero_Extracto + '", "Numero_Extracto_Movto": "' + Numero_Extracto_Movto + '", "Tipo_Factura_Movimiento": "' + Tipo_Factura_Movimiento + '", "Tipo_Transaccion": "' + Tipo_Transaccion + '", "Moneda_Movimiento": "' + Moneda_Movimiento + '", "Fecha_Movimiento": "' + Fecha_Movimiento2 + '", "Monto_Total": "' + Monto_Total + '", "Monto_Impuesto": "' + Monto_Impuesto + '", "Monto_Comision": "' + Monto_Comision + '", "Monto_Compra": "' + Monto_Compra + '", "Descripcion_Comercio": "' + Descripcion_Comercio + '", "Capital_Amortizado": "' + Capital_Amortizado + '", "Capital_Pendiente": "' + Capital_Pendiente + '", "Interes_Amortizado": "' + Interes_Amortizado + '", "Interes_Pendiente": "' + Interes_Pendiente + '", "Estado_Movimiento": "' + Estado_Movimiento + '", "Comision_Cancelacion": "' + Comision_Cancelacion + '", "Codigo_Subtipo_Mov": "' + Codigo_Subtipo_Mov + '", "Codigo_Tipo_Cuota": "' + Codigo_Tipo_Cuota + '", "Num_Operacion_Cuota": "' + Num_Operacion_Cuota + '", "Numero_Financiacion": "' + Numero_Financiacion + '", "Fecha_Ultima_Liquidacion": "' + Fecha_Ultima_Liquidacion + '", "Monto_Impuesto_Cancela": "' + Monto_Impuesto_Cancela + '", "Monto_Intereses_Regularizacion": "' + Monto_Intereses_Regularizacion + '", "Monto_Cancelacion": "' + Monto_Cancelacion + '", "Contro_Concurrencia": "' + Contro_Concurrencia + '", "Monto_Interes_Carecencia": "' + Monto_Interes_Carecencia + '", "Numero_Tarjeta_PAN": "' + Numero_Tarjeta_PAN + '", "Referencia": "' + Referencia + '", "Cod_Autorizacion": "' + Cod_Autorizacion + '", "Cod_Actividad": "' + Cod_Actividad + '", "IndSeleccionable": "' + IndSeleccionable + '", "Cod_Bloqueo": "' + Cod_Bloqueo + '", "Fecha_Bloqueo": "' + Fecha_Bloqueo2 + '", "Monto_Cuota": "' + Monto_Cuota + '", "Dsc_Tipo_Factura": "' + Dsc_Tipo_Factura + '", "Cod_Comercio": "' + Cod_Comercio + '", "Cod_Pais": "' + Cod_Pais + '"},';
  document.getElementById("check_json" + id_chk).value = '{"ID_Requerimiento_SAC": "' + ID_Requerimiento_SAC + '", "Fact_NoFact": "' + Fact_NoFact + '", "Numero_Extracto": "' + Numero_Extracto + '", "Numero_Extracto_Movto": "' + Numero_Extracto_Movto + '", "Tipo_Factura_Movimiento": "' + Tipo_Factura_Movimiento + '", "Tipo_Transaccion": "' + Tipo_Transaccion + '", "Moneda_Movimiento": "' + Moneda_Movimiento + '", "Fecha_Movimiento": "' + Fecha_Movimiento + '", "Monto_Total": "' + "102000" + '", "Monto_Impuesto": "' + Monto_Impuesto + '", "Monto_Comision": "' + Monto_Comision + '", "Monto_Compra": "' + Monto_Compra + '", "Descripcion_Comercio": "' + Descripcion_Comercio + '", "Capital_Amortizado": "' + Capital_Amortizado + '", "Capital_Pendiente": "' + Capital_Pendiente + '", "Interes_Amortizado": "' + Interes_Amortizado + '", "Interes_Pendiente": "' + Interes_Pendiente + '", "Estado_Movimiento": "' + Estado_Movimiento + '", "Comision_Cancelacion": "' + Comision_Cancelacion + '", "Codigo_Subtipo_Mov": "' + Codigo_Subtipo_Mov + '", "Codigo_Tipo_Cuota": "' + Codigo_Tipo_Cuota + '", "Num_Operacion_Cuota": "' + Num_Operacion_Cuota + '", "Numero_Financiacion": "' + Numero_Financiacion + '", "Fecha_Ultima_Liquidacion": "' + Fecha_Ultima_Liquidacion + '", "Monto_Impuesto_Cancela": "' + Monto_Impuesto_Cancela + '", "Monto_Intereses_Regularizacion": "' + Monto_Intereses_Regularizacion + '", "Monto_Cancelacion": "' + Monto_Cancelacion + '", "Contro_Concurrencia": "' + Contro_Concurrencia + '", "Monto_Interes_Carecencia": "' + Monto_Interes_Carecencia + '", "Numero_Tarjeta_PAN": "' + Numero_Tarjeta_PAN + '", "Referencia": "' + Referencia + '", "Cod_Autorizacion": "' + Cod_Autorizacion + '", "Cod_Actividad": "' + Cod_Actividad + '", "IndSeleccionable": "' + IndSeleccionable + '", "Cod_Bloqueo": "' + Cod_Bloqueo + '", "Fecha_Bloqueo": "' + Fecha_Bloqueo + '", "Monto_Cuota": "' + Monto_Cuota + '", "Dsc_Tipo_Factura": "' + Dsc_Tipo_Factura + '", "Cod_Comercio": "' + Cod_Comercio + '", "Cod_Pais": "' + Cod_Pais + '"},';

    // }
  } else {
    document.getElementById("check" + id_chk).value = "0-" + id_chk + "-" + fecha + "-" + Dsc_Tipo_Factura + "-" + establecimiento + "-" + monto;
  document.getElementById("check_json" + id_chk).value = "";
  }
}

function disableInput() {
  var alMenosUnaCheck = $('#form1 input[type=checkbox]:checked').length > 0;
  if (alMenosUnaCheck) {
    $("#nacional").prop('disabled', true);
    $("#internacional").prop('disabled', true);
    if (document.getElementById("TipoFac").value == "F") {
      $("#fechaFacturacion").prop('disabled', true);
    }
  } else {
    $("#nacional").prop('disabled', false);
    $("#internacional").prop('disabled', false);
    if (document.getElementById("TipoFac").value == "F") {
      $("#fechaFacturacion").prop('disabled', false);
    }
  }
}


function mostrar_modal(id_modal) {
  document.getElementById("mensajeerror" + id_modal).style.display = 'block';
  //document.getElementById("mensaje1").value = "RR";

}

function btnSalirAceptar(id_modal) {
  document.getElementById("mensajeerror" + id_modal).style.display = 'none';
}

function validar_opcion() {
   document.getElementById("ref").value = "true";
  var iterar = parseInt(document.getElementById("trtj_position").value);
  var trjt_acum = 0;
  for (i=0; i<=iterar-1; i++) {
  if (!(document.getElementById("radio1"+i).checked) && !(document.getElementById("radio2"+i).checked)) {
    mostrar_modal("_s/n");
  }
  else //si alguno de los dos=checked
  {
    if (NacInt(i)) {
      trjt_acum++;
    }
  }  
  }
  if (trjt_acum === iterar) {
    var entrada = "";
    indicadores.forEach( function(value, key) {
    entrada += value.tarjeta + ";" + value.enPoder + ";" + value.extranjero + ";" + value.pais + ";" + value.ciudad + ";" + value.desde + ";" + value.hasta + "|";
    });
    entrada = entrada.slice(0, -1);
    document.getElementById("indicadores").value = entrada;
    $('#ntf-loading').show();// document.getElementById("form1").action = "datosContacto_view.asp";
    document.getElementById("form1").submit();
  }
}

function NacInt(id) {
  switch (document.getElementById("MovInter").value) {
      
    case "N":
      return true;
      /*$('#ntf-loading').show();// document.getElementById("form1").action = "datosContacto_view.asp";
      document.getElementById("form1").submit();*/
      break;
      
    default:
      if (!(document.getElementById("extsns"+id).checked) && !(document.getElementById("extsnn"+id).checked)) // estuvo en el exterios las dos=unchecked
      {
        mostrar_modal("_extranjero");
        return false;
      } else // estuvo en el exterios alguna de las dos=checked
      {
        if (document.getElementById("extsns"+id).checked) //si estuvo en el extranjero
        {
        if ((document.getElementById("ciudadE"+id).value == "") || (document.getElementById("paisE"+id).value == "") || (document.getElementById("dateInit"+id).value.trim() == "")) {
          mostrar_modal("_datosextranjero");
          return false;
        }/* else//if ((document.getElementById("ciudadE").value !="") && (document.getElementById("paisE").value !="") && (document.getElementById("dateInit").value.trim() ==""))
        {
          $('#ntf-loading').show();
          document.getElementById("form1").submit();

        }*/
        } /*else //no estuvo
        {
        $('#ntf-loading').show();// document.getElementById("form1").action = "datosContacto_view.asp";
        document.getElementById("form1").submit();
        }*/
      }
      return true;
      break;
  }
}

function ContarLetras(input) {
  var x = document.getElementById("descrip").value.trim().length;

  document.getElementById("control").textContent = x;

  document.getElementById("control").textContent = document.getElementById("control").textContent + "/100";
  if (x >= 100) {
    document.getElementById("descrip").value = document.getElementById("descrip").value.slice(0, 100);
    document.getElementById("control").textContent = "100/100";
  }

}

function btnContinuaSig() {
  document.getElementById("ref3").value = "true";
  if (document.getElementById("check1") !== null) {
    if (!(document.getElementById("check1").checked)) {
      $("#Mensaje1").html("<h2>Estimado Cliente: Debe seleccionar Bloqueo definitivo de Tarjeta.</h2>");
      mostrar_modal("Bloq1");
    } else {
      if (!(document.getElementById("radio1").checked) && !(document.getElementById("radio2").checked)) {
        $("#Mensaje1").html("<h2>Estimado Cliente: Debe seleccionar d&oacute;nde desea retirar la tarjeta.</h2>");
        mostrar_modal("Bloq1");
      } else {

          if ((document.getElementById("cl1").value == "") || (document.getElementById("cl2").value == "") || (document.getElementById("cl3").value == "") || (document.getElementById("cl4").value == "")) {
            $("#Mensaje1").html("<h2>Estimado Cliente: Debe Ingresar Clave de Internet</h2>");
            mostrar_modal("Bloq1");
          } else {
            $('#ntf-loading').show();
      $.ajax({
        url: "validacion_clave.asp",
        type: 'POST',
        data: {
          'cl1': $("#cl1").val(),
          'cl2': $("#cl2").val(),
          'cl3': $("#cl3").val(),
          'cl4': $("#cl4").val()
        },
        success: function(data) {
          if (data.indexOf("clave invalida|NOK") == -1) {
            $("#errorclave").html("");
            $("#formulario").submit();
          } else {
            $("#cl1").val("");
            $("#cl2").val("");
            $("#cl3").val("");
            $("#cl4").val("");
            //$("#errorclave").html(data);
            $('#errorClaveInternet').show();
            $('#ntf-loading').hide();
            //$("#cl1").focus();
          }
        },
        error: function(d) {
          console.log (d);
        }
      });
          }

            }
          }
  }else {
    if ((document.getElementById("cl1").value == "") || (document.getElementById("cl2").value == "") || (document.getElementById("cl3").value == "") || (document.getElementById("cl4").value == "")) {
      $("#Mensaje1").html("<h2>Estimado Cliente: Debe Ingresar Clave de Internet</h2>");
      mostrar_modal("Bloq1");
    } else {
      $('#ntf-loading').show();
      $.ajax({
        url: "validacion_clave.asp",
        type: 'POST',
        data: {
          'cl1': $("#cl1").val(),
          'cl2': $("#cl2").val(),
          'cl3': $("#cl3").val(),
          'cl4': $("#cl4").val()
        },
        success: function(data) {
          if (data.indexOf("clave invalida|NOK") == -1) {
            $("#errorclave").html("");
            $("#formulario").submit();
          } else {
            $("#cl1").val("");
            $("#cl2").val("");
            $("#cl3").val("");
            $("#cl4").val("");
            //$("#errorclave").html(data);
            $('#errorClaveInternet').show();
            $('#ntf-loading').hide();
            //$("#cl1").focus();
          }
        },
        error: function(d) {
          console.log (d);
        }
      });
      
    //document.getElementById("formulario").submit();
    }
  }
}

function btnValidar() {
  $('#ntf-loading').show();
    document.getElementById("formulario").submit();
}

function fClave() {

  var vClave = document.getElementById("vClave").value;

  if (vClave == "0") {
    vClave = "1";
  } else {
    vClave = "0";
  }
  document.getElementById("vClave").value = vClave;

}

function soloNumeros(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

  return true;
}

//Variables globales usadas para la asignacion de estatus de las tarjetas
var INDICADORES_TARJETAS  = new Array();

function asigna_var(estatus, index, opcion) {
  //Comprueba si es una primera asignación o un cambio
  var validaEntrada = (index >= INDICADORES_TARJETAS.length && INDICADORES_TARJETAS[index] === undefined) ? true: false;
  
  switch (opcion) {
    case 'T':
      if (validaEntrada) {
        INDICADORES_TARJETAS.push({"enPoder": estatus, "tarjeta" : ""});
      } else {
        INDICADORES_TARJETAS[index].enPoder = estatus;
      }
      
    break;
    case 'E':
      if (validaEntrada){
        INDICADORES_TARJETAS.push({"extranjero": estatus, "tarjeta" : ""});
      } else {
        INDICADORES_TARJETAS[index].extranjero = estatus;
      }
    break;
  }
}

function validar_opcion() {
  document.getElementById("ref").value = "true";
  var iterar = parseInt(document.getElementById("trtj_position").value);
  var trjt_acum = 0;
  for (i=0; i<=iterar-1; i++) {
  if (!(document.getElementById("radio1"+i).checked) && !(document.getElementById("radio2"+i).checked)) {
    mostrar_modal("_s/n");
  }
  else //si alguno de los dos=checked
  {
    if (NacInt(i)) {
      trjt_acum++;
    }
  }  
  }
  if (trjt_acum === iterar) {
    var entrada = "";
    INDICADORES_TARJETAS.forEach( function(value, key) {
      if (value.extranjero !== undefined) {       
      entrada += value.tarjeta + ";" + value.enPoder + ";" + value.extranjero + ";" + value.pais + ";" + value.ciudad + ";" + value.desde + ";" + value.hasta + "|";
      }else {
        // POR DEFECTO SE DEBE ENVIAR EL INDICADOR DE ESTUVO EL EXTRANJERO COMO 'N' SEGUN LO CONVERSADO CON MICHEL
      entrada += value.tarjeta + ";" + value.enPoder + ";N;;;;|";
      }
    });
    entrada = entrada.slice(0, -1);
    document.getElementById("indicadores").value = entrada;
    $('#ntf-loading').show();// document.getElementById("form1").action = "datosContacto_view.asp";
    document.getElementById("form1").submit();
  }
}

function NacInt(id) {
  switch (document.getElementById("MovInter").value) {
      
    case "N":
      return true;
      /*$('#ntf-loading').show();// document.getElementById("form1").action = "datosContacto_view.asp";
      document.getElementById("form1").submit();*/
      break;
      
    default:
      if (!(document.getElementById("extsns"+id).checked) && !(document.getElementById("extsnn"+id).checked)) // estuvo en el exterios las dos=unchecked
      {
        mostrar_modal("_extranjero");
        return false;
      } else // estuvo en el exterios alguna de las dos=checked
      {
        //cambios 
        INDICADORES_TARJETAS[id].ciudad = "";
        INDICADORES_TARJETAS[id].pais = "";
        INDICADORES_TARJETAS[id].desde = "";
        INDICADORES_TARJETAS[id].hasta = "";

        if (document.getElementById("extsns"+id).checked) //si estuvo en el extranjero
        {
        if ((document.getElementById("ciudadE"+id).value == "") || (document.getElementById("paisE"+id).value == "") || (document.getElementById("dateInit"+id).value.trim() == "")) {
          mostrar_modal("_datosextranjero");
          return false;
        } else {
            INDICADORES_TARJETAS[id].ciudad = document.getElementById("ciudadE"+id).value;
            INDICADORES_TARJETAS[id].pais = document.getElementById("paisE"+id).value;
            INDICADORES_TARJETAS[id].desde = document.getElementById("f_desde"+id).value.trim();
            INDICADORES_TARJETAS[id].hasta = document.getElementById("f_hasta"+id).value.trim();
          }
        }
      }
      return true;
      break;
  }
}


if(document.getElementById("show_Modal") !== null) {
  if (document.getElementById("show_Modal").value == "show") {
    $(".modal-op").fadeIn();
    //document.getElementById("sinMovimientos").style.display = "block";
  }
}

/*        Sac 2       */




function btnAceptar()
{
  var total = document.getElementById("total").value;   
  var panTarjeta = "";
  var cnAltas = "";
  var nroCuenta = "";
  var idReCall = "";
  var txtDesProd = "";
  var txtCodTCR ="";
  var txtNMtCR ="";
  var txtSubP = "";
  
  var seleccion = document.getElementById("TipoFac").value;
  
  var contador = 0;
    
  for (var i = 1; i <= total; i++) {
    
    if ($("#check" + i).is(":checked") == true)
    {
      $('#ntf-loading').show();
    
      panTarjeta = $("#txtPan" + i).val();
      cnAltas = $("#txtCnAlta" + i).val();
      nroCuenta = $("#txtCuenta"+ i).val();
      idReCall = $("#txtRecall"+ i).val();
      txtDesProd = $("#txtGltCr"+ i).val();
      txtCodTCR =  $("#txtCodTCR"+ i).val();
      txtNMtCR =  $("#txtNMtCR"+ i).val();
      txtSubP =  $("#txtSubproducto"+ i).val();
      
      var select = document.getElementById('seleccionComb'+i);  
            
      document.getElementById("NumeroTCR").value = panTarjeta;
      document.getElementById("TipoMov").value = "N";//select.value; //nacional o internacional
      document.getElementById("CnAlt").value = cnAltas;     
      document.getElementById("NumContrt").value = nroCuenta; 
      document.getElementById("GlsTcr").value = txtDesProd; 
      document.getElementById("CodTCR").value = txtCodTCR;
      document.getElementById("NMtCR").value = txtNMtCR;
      document.getElementById("TipoFac").value = select.value; //facturado o por facturar
      document.getElementById("txtsubProd").value = txtSubP;
      
      document.getElementById("valorCheck").value = $("#check" + i).val();
      
  
      if (select.value == "F")
      {
        //Facturados 
        document.getElementById("formulario").action="selMovimientos_view.asp";
        document.getElementById("formulario").submit();
      }
      else{     
        //Por Facturar
        document.getElementById("formulario").action="selMovimientos_view.asp";
        document.getElementById("formulario").submit();
      }
      
    }
    else
    { 
      contador = contador + 1;  
    }
  }
  
  if (contador == total)
  {   
    mostrar_modal2();
  }
}

function TipoSeleccion(valor)
{ 
  $('#ntf-loading').show();

  var opcion = valor;
  var tipoFac = document.getElementById('TipoFac').value;
  var nombre = $("#txtNombreTCR").val();


  if (tipoFac == "F")
  {
    //Facturados 
    document.getElementById("TipoMov").value = opcion;
    document.getElementById("txtNombreTCR").value = nombre;
    var numext  = $("#fechaFacturacion").val();
    var fechaSelect = $("#fechaFacturacion option:selected").text();
    var dateParts = fechaSelect.split("/");
    var date = dateParts[2] + "-" + dateParts[1] + "-" + dateParts[0];
    document.getElementById("fechaSelected").value = date; 
    $(fechaFacturacion).val(document.getElementById('nume').value);
    document.getElementById("nume").value = numext;
    document.getElementById("form1").action="selMovimientos_view.asp?filtro=SI";
    document.getElementById("form1").submit();
  }
  else{     
    //Por Facturar  
    document.getElementById("TipoMov").value = opcion;
    document.getElementById("txtNombreTCR").value = nombre;
    document.getElementById("form1").action="selMovimientos_view.asp?filtro=SI";
    document.getElementById("form1").submit();  
  }
  
}

function mostrar_modal2() {
  document.getElementById("mensajeSeleccion").style.display = 'block';
}
function btnSalirAceptar2() {
  document.getElementById("mensajeSeleccion").style.display = 'none';
}

/*function btnSalir() {
  document.getElementById("sinMovimientos").style.display = 'none';
}

if(document.getElementById("show_Modal") !== null) {
  if (document.getElementById("show_Modal").value == "show") {
    document.getElementById("sinMovimientos").style.display = "block";
  }
}*/

function buscar()
{
  $('#ntf-loading').show();
  
  var numext, url;
  
  numext  = $("#fechaFacturacion").val();
  
  var fechaSelect = $("#fechaFacturacion option:selected").text();
  var dateParts = fechaSelect.split("/");
  var date = dateParts[2] + "-" + dateParts[1] + "-" + dateParts[0];
  document.getElementById("fechaSelected").value = date;
  //alert("numext: "+numext); 
  $(fechaFacturacion).val(document.getElementById('nume').value);
  document.getElementById("nume").value = numext;
  document.getElementById("form1").action = "selMovimientos_view.asp?filtro=SI";
  document.getElementById("form1").submit();  
}

function btnSalirAceptar3() {
  document.getElementById("formulario").action="/transa/segmentos/welcome.asp";
  document.getElementById("formulario").submit(); 
}

  /*$(document).ready(function(){
    var fec = $("#txtFechas").val();
    var txtNumero2 = $("#txtNumero").val();
      
      
    /*if (fec == "" || fec == undefined)
    {
      alert("fec: "+ fec);
      $("#btnContinuar2").removeClass("primary");
      document.getElementById('btnContinuar2').disabled = true;
      
    }
    else if(txtNumero2 == 0 ||txtNumero2 == "")
    {
      alert("txtNumero2: "+ txtNumero2);
      $("#btnContinuar2").removeClass("primary");
      document.getElementById('btnContinuar2').disabled = true;
    }
    else
    {
      alert("else: ");
      $("#btnContinuar2").addClass("primary");  
      document.getElementById('btnContinuar2').disabled = false;
    } 
    
  });*/
  

/*function buscar()
{
  alert("busca");
  
  if ()
  //"NACF":
  url   = "pruebaFecha.asp";
  numext  = $("#numext").val();
  tipo  = "nac";          
  $("#flgFacturado").val("F");
  
  
}*/


