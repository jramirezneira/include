$(document).ready(function () {
	var roclo = false;
	var sino = false;
	var calen = false;
	var nopoder = false;
	var clonal = false;
 	$('input[name="options"]').change(function(event) {
		if ($("input[name='options']:checked").val() == '1') {
	        $('.suboption').show();
	    }else{
	    	$('.suboption').hide();
	    } 
	}); 
	$('input.sino').change(function(){
		if( $(this).val() == '0' && $(this).is(':checked') ){
			$(this).parent().parent().parent().find(".paisCont").css("display", "inline-block");
		}else if( $(this).val() == '1' && $(this).is(':checked') ){
			$(this).parent().parent().parent().find(".paisCont").hide();
		}
	});
	$(".button.primary.disabled").click(function(e){
		if( $(this).hasClass("disabled") ){
			e.preventDefault();
		}
	});
	$("input.clonfal").click(function(){
		$('#ccbtn').removeClass('disabled');
		clonal = true;
	});
	$("input.nmpoder").click(function(){
		if( $(this).val() == '1' && $(this).is(':checked') ){
			$('#ccbtn').addClass('disabled');
		}
	});
	$("input.roclo").click(function(){
		roclo = true;
		if(sino){
			$('#ccbtn').removeClass('disabled');
		}
	});

	$("input.sino").click(function(){
		if( $(this).val() == '1' && $(this).is(':checked') && roclo ){
			$('#ccbtn').removeClass('disabled');
		}
		if( $(this).val() == '1' ){
			sino = true;
		}
		if( $(this).val() == '0' ){
			sino = false;
			$('#ccbtn').addClass('disabled');
		}
	});
	$(".nmpoder").click(function(){
		if( $(this).val() == '1' ){
			nopoder = true;
		}
		if( $(this).val() == '0' && nopoder && clonal ){
			$('#ccbtn').removeClass('disabled');
		}
	})
	$(".paisE, .ciudadE").focusout(function(){
		if( !$(".paisE").val() == '' && !$(".ciudadE").val() == '' && $(".inputCalendario").val() ){
			$('#ccbtn').removeClass('disabled');
		}
	});
	$("#ccbtn").click(function(){
		if( $(".paisE ").val() == '' ){
			$(".paisE ").parent().addClass("error");
		}else{
			$(".paisE ").parent().removeClass("error");
		}
		if( $(".ciudadE").val() == '' ){
			$(".ciudadE ").parent().addClass("error");
		}else{
			$(".ciudadE ").parent().removeClass("error");
		}
	});
});
