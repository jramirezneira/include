Number.isNaN = Number.isNaN || function(value) {
   return typeof value === "number" && isNaN(value);
}

function equalHeight(group) {
  var tallest = 0;
  group.each(function() {
	 var thisHeight = $(this).outerHeight();
	 if (thisHeight > tallest) {
		   tallest = thisHeight;
	 }
  });
  group.outerHeight(tallest);
}
if ($(window).width() > 768) {
   equalHeight($(".sameHeight"));
}


$(document).ready(function() {

   var inputs = $('.input');

   $('.only_text').on('input', function() {
		this.value = this.value.replace(/[^a-zA-ZÑñ ]/g, '');
	});

   $('body').on('click', '.btn-click-open-modal', function(e) {

      var modalgeneral = $('.bg-modal');
      var modalopen = $(this).data('modal-open');

      if( !$(this).hasClass('disabled')) {
         modalgeneral.filter('[data-modal="' + modalopen + '"]').fadeIn();
      }
   });

   $("body").on('click', '.btn-aceptar-modal', function(event) {
      $('.bg-modal').fadeOut();
	  $("#cl1").focus();
      return false;
   });

   $('.btn-cerrar-modal').on('click', function() {
      var valorUrl = $(this).data('url');
      if (valorUrl != "") {
         window.location.href = valorUrl;
      } else {
		 $("#cl1").focus();
         $('.bg-modal').fadeOut();
      }

   });

});