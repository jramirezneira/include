var MAP;
var GEOCODER;
var MARKERUBICACION;
var LASTOPENEDINFOWINDOW;

function initMap() {
  MAP = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    center: {lat: -33.4381522, lng: -70.6514932},
    streetViewControl: false,
    disableDefaultUI: true
  });
  GEOCODER = new google.maps.Geocoder();
  document.getElementById('submit').addEventListener('click', function() {
    geocodeAddress(GEOCODER, MAP);
  });
  document.getElementById('address').addEventListener('keypress', function(e) {
    var code = (e.keyCode ? e.keyCode : e.which);
    if(code == 13) {
      geocodeAddress(GEOCODER, MAP);
    }
  });
  document.getElementById('location').addEventListener('click', function() {
    navigator.geolocation.getCurrentPosition(showPosition,showError);
    document.getElementById('address').value = "";
  });
  var i = 0;
  for(i = 0; i < MARCADORES_SUCURSALES.length; i++){ 
    createMarker_all(MARCADORES_SUCURSALES[i]); 
  }
  navigator.geolocation.getCurrentPosition(showPosition,showError);
}

function showPosition(position){
  var lat = position.coords.latitude;
  var lon = position.coords.longitude;
  var pyrmont = {lat: lat, lng: lon};
  if(MARKERUBICACION!=undefined){
    MARKERUBICACION.setMap(null);
  }
  MARKERUBICACION = new google.maps.Marker({
    map: MAP,
    position: pyrmont
  });
  MAP.setCenter(pyrmont);
  MAP.setZoom(17);
}

function geocodeAddress(geocoder, resultsMap) {
  var address = document.getElementById('address').value;
  geocoder.geocode({'address': address}, function(results, status) {
    if (status === 'OK') {
      resultsMap.setCenter(results[0].geometry.location);
      resultsMap.setZoom(17);
      if(MARKERUBICACION!=undefined){
        MARKERUBICACION.setMap(null);
      }
      MARKERUBICACION = new google.maps.Marker({
        map: resultsMap,
        position: results[0].geometry.location
      });
    } else {
      console.log('Geocode was not successful for the following reason: ' + status);
    }
  });
}

function showError(error){
  switch(error.code){
    case error.PERMISSION_DENIED:
      console.log("Denegada la peticion de Geolocalización en el navegador");
      break;
    case error.POSITION_UNAVAILABLE:
      console.log("La información de la localización no esta disponible.");
      break;
    case error.TIMEOUT:
      console.log("El tiempo de petición ha expirado.");
      break;
    case error.UNKNOWN_ERROR:
      console.log("Ha ocurrido un error desconocido.");
      break;
  }
}

function createMarker_all(place){
  var markerSuc;
  var infoWindow;
  var Select;
  Select = document.getElementById('hidden').value;
  
  if(place[6]=="SI"){
    if(Select == "1"){
      //SELECT
      markerSuc = new google.maps.Marker({
        map: MAP,
        position: {lat:place[1],lng:place[2]},
        title:place[0] + ', ' + place[3],
        icon: 'css/img/pin-santander.png' 
      });
    }else{
      if(!(place[0].search("select")>-1 || place[0].search("Select")>-1 || place[0].search("SELECT")>-1)){
        markerSuc = new google.maps.Marker({
          map: MAP,
          position: {lat:place[1],lng:place[2]},
          title:place[0] + ', ' + place[3],
          icon: 'css/img/pin-santander.png' 
        });
      }
    }

    /*
    if(place[0].search("select")>-1 || place[0].search("Select")>-1 || place[0].search("SELECT")>-1){
      //SELECT
      markerSuc = new google.maps.Marker({
        map: MAP,
        position: {lat:place[1],lng:place[2]},
        title:place[0] + ', ' + place[3],
        icon: 'css/img/pin-santander.png' 
      });
    }else{
      //NO SELECT
      markerSuc = new google.maps.Marker({
        map: MAP,
        position: {lat:place[1],lng:place[2]},
        title:place[0] + ', ' + place[3],
        icon: 'css/img/pin-santander.png'
      });
    }
    */
  }
  if(markerSuc!=undefined){
    infoWindow = new google.maps.InfoWindow({
      content: '<div class="iwContent">' +
               '  <h3>' + place[0] + '</h3>' +
               '   <p>' + place[3] + '</p>' +
               '</div>'
    });
    markerSuc.addListener('click', function() {
      if(LASTOPENEDINFOWINDOW){
        LASTOPENEDINFOWINDOW.close();
      }
      infoWindow.open(MAP, markerSuc);
      LASTOPENEDINFOWINDOW = infoWindow;
    });
  }
}